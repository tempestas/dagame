package engine;

import gui.GOModel;

/**
 * GameObject as a box
 * @author Sascha Eckert, Martin Reimund
 */
public class Box extends GameObject {
	
	/**
	 * Move angle
	 */
	private byte angle;
	
	/**
	 * Box constructor
	 * @param posx Box position x
	 * @param posy Box position y
	 * @param model Box model
	 */
	public Box(int posx, int posy, GOModel model) {
		super(posx, posy, model);
		this.setMoveSpeed(5 * ((int)(Math.random() * 3 + 1)));
	}
	
	/**
	 * Box constructor
	 * @param posx Box position x
	 * @param posy Box position y
	 * @param moveSpeed Box y move speed
	 * @param model Box model
	 */
	public Box(int posx, int posy, int moveSpeed, GOModel model) {
		super(posx, posy, model);
		this.setMoveSpeed(moveSpeed);
	}
	
	/**
	 * Moves box one step forward and adjust angle
	 */
	public void move() {
		if(this.getAngle() != 0) {
			this.setCurPos(this.getCurPos(0) - this.getAngle(), this.getCurPos(1));
			if(this.getCurPos(0) - this.getAngle() < 0) {
				this.setAngle((byte)-this.getAngle());
			}
			if(this.getCurPos(0) + this.getWidth() > 640) {
				this.setAngle((byte)-this.getAngle());
			}
		}
		this.setLastPos(this.getCurPos(0), this.getCurPos(1));
		this.setCurPos(this.getCurPos(0), this.getCurPos(1) - this.getMovespeed());
	}
	
	/**
	 * Get angle, set to random angle between 5/-5 if unset
	 * @return angle
	 */
	public byte getAngle() {
		if(this.angle == 0) {
			this.angle = (byte)((-5) + (int)(Math.random() * (5 - (-5) + 1)));
		}
		return this.angle;
	}
	
	public void setAngle(byte angle) {
		this.angle = angle;
	}
}
